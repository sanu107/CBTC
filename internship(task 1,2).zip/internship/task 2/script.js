document.getElementById('new-task-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const taskContent = document.getElementById('new-task-content').value;
    if (taskContent) {
        addTask(taskContent);
        document.getElementById('new-task-content').value = ''; // Clear input after adding
    }
});

function addTask(content) {
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-center';
    li.textContent = content;

    const completeButton = document.createElement('button');
    completeButton.className = 'btn btn-success btn-sm';
    completeButton.textContent = 'Complete';
    completeButton.onclick = function() {
        completeTask(li, content);
    };

    li.appendChild(completeButton);
    document.getElementById('task-list').appendChild(li);
}

function completeTask(taskElement, content) {
    document.getElementById('task-list').removeChild(taskElement);
    
    const completedLi = document.createElement('li');
    completedLi.className = 'list-group-item completed';
    completedLi.textContent = content;

    document.getElementById('completed-task-list').appendChild(completedLi);
}
